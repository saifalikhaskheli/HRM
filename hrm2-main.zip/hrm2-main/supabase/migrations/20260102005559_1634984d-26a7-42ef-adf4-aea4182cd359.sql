-- Add my_team to the permission_module enum
ALTER TYPE permission_module ADD VALUE IF NOT EXISTS 'my_team';