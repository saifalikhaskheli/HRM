-- Link user account to existing employee record
UPDATE employees 
SET user_id = 'f0702067-021e-4fc6-8394-8e921970c8ed'
WHERE id = '315ca5fd-3752-470d-ad32-90b9d7727e9d';